from django.contrib.auth.decorators import login_required
from .models import User,  Userpayments, Profile, Price
from django.views.decorators.csrf import csrf_exempt
from captcha.widgets import ReCaptchaV2Checkbox
from django.shortcuts import render, redirect
from captcha.fields import ReCaptchaField
from django.http import HttpResponse
from django.conf import settings
from django.urls import reverse
from datetime import datetime
from django import forms
import stripe
import time


stripe.api_key = settings.STRIPE_KEY
stripe_public_keys = settings.STRIPE_PUBLIC_KEY
end_point_secret = settings.WEBHOOK_KEY


class FormWithCaptcha(forms.Form):
    captcha = ReCaptchaField(widget=ReCaptchaV2Checkbox(attrs={'label': ''}))


def payment_after_registeration(request, param1):
    user = User.objects.get(id=param1)
    price = Price.objects.all()
    context = {
        "captcha": FormWithCaptcha,

        "user_id": user.id,
        "prices": price
    }

    return render(request, 'choose_package.html', context)


def payment_at_registration(request):
    if request.method == 'POST':
        form = FormWithCaptcha(request.POST)
        if form.is_valid():
            user_id = request.POST.get('user_id')
            account_type = request.POST.get('account_type')

            recaptcha_response = form.cleaned_data['captcha']
            if Price.objects.filter(first_month_token=account_type).exists():
                price_from_model = Price.objects.filter(
                    first_month_token=account_type).first()
                price_first_month_id = price_from_model.first_month_token
                next_price_id = price_from_model.subsequent_months_token

                # Create a checkout session
                session = stripe.checkout.Session.create(
                    line_items=[
                        {
                            'price': price_first_month_id,

                            'quantity': 1
                        },

                    ],
                    mode='subscription',
                    metadata={"user_id": user_id,
                              "next_price_id": next_price_id,
                              "is_yearly": False,
                              "properties": 1,
                              'is_registered': 0

                              },
                    payment_method_types=['card'],
                    success_url=request.build_absolute_uri(
                        reverse('success_3')) + '?session_id={CHECKOUT_SESSION_ID}',
                    cancel_url=request.build_absolute_uri(reverse('cancel'))
                )

            elif Price.objects.filter(first_year_token=account_type).exists():
                price_from_model = Price.objects.filter(
                    first_year_token=account_type).first()
                yearly_token = price_from_model.subsequent_years_token
                price_first_month_id = price_from_model.first_year_token

                # Create a checkout session
                session = stripe.checkout.Session.create(
                    line_items=[
                        {
                            'price': price_first_month_id,

                            'quantity': 1
                        },

                    ],
                    mode='subscription',
                    metadata={"user_id": user_id,
                              "next_price_id": yearly_token,
                              "is_yearly": True,
                              "properties": 1,
                              'is_registered': 0

                              },
                    payment_method_types=['card'],
                    success_url=request.build_absolute_uri(
                        reverse('success_3')) + '?session_id={CHECKOUT_SESSION_ID}',
                    cancel_url=request.build_absolute_uri(reverse('cancel'))
                )

            context = {
                'session_id': session.id,
                'stripe_public_keys': stripe_public_keys}
            return render(request, 'checkout.html', context)

        else:
            print('Form errors:', form.errors)
            context = {
                "captcha": form,
                "user_id": request.POST.get('user_id'),
                "prices": Price.objects.all()
            }
            return render(request, 'choose_package.html', context)
    else:
        return redirect('price')


def success_third(request):
    session_id = request.GET.get('session_id')

    session = stripe.checkout.Session.retrieve(session_id)
    next_price_id = session.metadata.get('next_price_id')

    is_registered = session.metadata.get('is_registered')
    print(type(is_registered))
    user_id = session.metadata.get('user_id')
    yearly = session.metadata.get('is_yearly')
    subscription_id = session.subscription
    subscription = stripe.Subscription.retrieve(subscription_id)
    user_subscription = subscription['items']['data'][0]['id']
    customer = subscription.customer

    customer = stripe.Customer.retrieve(session.customer)
    print(customer)

    updatedd_subscription = stripe.Subscription.modify(
        subscription_id,
        items=[{
            'id': user_subscription,
            'price': next_price_id,
        }],
        metadata={
            "user_id": user_id,
            "next_price_id": next_price_id,
            "is_yearly": yearly,
            "properties": 1

        },
    )
    if int(is_registered) == 1:
        print("Registerd")

        return render(request, 'success.html')
    else:
        print("Not Registerd")
        return render(request, 'success_3.html')



# @login_required(login_url='login')
def become_pro(request):
    if request.user.is_authenticated:
        if request.method == 'POST':

            user_id = request.user.id
            account_type = request.POST.get('account_type')

            if Price.objects.filter(first_month_token=account_type).exists():

                price_from_model = Price.objects.filter(
                    first_month_token=account_type).first()
                price_first_month_id = price_from_model.first_month_token
                next_price_id = price_from_model.subsequent_months_token

                # Create a checkout session
                session = stripe.checkout.Session.create(
                    line_items=[
                        {
                            'price': price_first_month_id,

                            'quantity': 1
                        },

                    ],
                    mode='subscription',
                    metadata={"user_id": user_id,
                              "next_price_id": next_price_id,
                              "is_yearly": False,
                              "properties": 1,
                              'is_registered': 1

                              },
                    payment_method_types=['card'],
                    success_url=request.build_absolute_uri(
                        reverse('success_3')) + '?session_id={CHECKOUT_SESSION_ID}',
                    cancel_url=request.build_absolute_uri(reverse('cancel'))
                )

                context = {
                    'session_id': session.id,
                    'stripe_public_keys': stripe_public_keys}
                return render(request, 'checkout.html', context)

            elif Price.objects.filter(first_year_token=account_type).exists():
                price_from_model = Price.objects.filter(
                    first_year_token=account_type).first()

                yearly_token = price_from_model.subsequent_years_token
                price_first_month_id = price_from_model.first_year_token

                # Create a checkout session
                session = stripe.checkout.Session.create(
                    line_items=[
                        {
                            'price': price_first_month_id,

                            'quantity': 1
                        },

                    ],
                    mode='subscription',
                    metadata={"user_id": user_id,
                              "next_price_id": yearly_token,
                              "is_yearly": True,
                              "properties": 1,
                              'is_registered': 1
                              },
                    payment_method_types=['card'],
                    success_url=request.build_absolute_uri(
                        reverse('success_3')) + '?session_id={CHECKOUT_SESSION_ID}',
                    cancel_url=request.build_absolute_uri(reverse('cancel'))
                )

                context = {
                    'session_id': session.id,
                    'stripe_public_keys': stripe_public_keys}
                return render(request, 'checkout.html', context)

        return redirect('price')
    else:
        return redirect("register")


@csrf_exempt
def stripe_webhook(request):

    endpoint_secret = end_point_secret

    event = None
    payload = request.body
    sig_header = request.headers['STRIPE_SIGNATURE']

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, endpoint_secret
        )
        # print(event)

    except ValueError as e:
        # Invalid payload
        raise e

    # handle the checkout.session.completed event
    if event["type"] == "checkout.session.completed":

        session = event["data"]["object"]

        cs_token = session['customer']
        subs_token = session['subscription']
        user_id = session['metadata']['user_id']
        subsequent_months_token = session['metadata']['next_price_id']
        is_yearly = session['metadata']['is_yearly']
        user = User.objects.get(id=user_id)
        price = Price.objects.get(
            subsequent_months_token=subsequent_months_token)
        profile_object = Profile.objects.filter(user=user).first()

        can_add_properties = price.number_of_properties
        profile_object.is_pro = True
        profile_object.can_add = can_add_properties
        profile_object.strip_subscription_token = subs_token

        profile_object.strip_costumer_token = cs_token
        profile_object.pro_start_date = datetime.now()
        profile_object.is_yearly = is_yearly
        profile_object.save()
        total_money = int(session['amount_total'])/100

        try:
            user_payment = Userpayments.objects.get(user=user)
            user_payment.total_payment += total_money
            user_payment.recent_payment = total_money
            user_payment.recent_payment_is_yearly = is_yearly
            user_payment.customer_token = profile_object.strip_costumer_token,
            user_payment.subscription_token = profile_object.strip_subscription_token
            user_payment.save()
        except:
            pass
    if event["type"] == "customer.subscription.updated":
        session = event["data"]["object"]
        subscription = session["items"]["data"][0]["subscription"]
        user_id = session['metadata']['user_id']

        # print(subscription)
        user = User.objects.get(id=user_id)
        is_yearly = session['metadata']['is_yearly']

        print("Line 227 in Stripe Views")
        profile_object = Profile.objects.filter(user=user).first()

        total_money = None
        try:
            total_money = int(session['amount_total'])/100
        except:

            unit_amount = session['plan']['amount']
            quantity = session['quantity']
            total_money = int(unit_amount) * int(quantity)

        print("This is updated")

        cs_token = session['customer']
        if session['metadata']['properties']:
            properties = session['metadata']['properties']
            can_add_properties = properties
            profile_object.can_add = can_add_properties
        else:
            subsequent_months_token = session['metadata']['next_price_id']

            price = Price.objects.get(
                subsequent_months_token=subsequent_months_token)
            can_add_properties = price.number_of_properties
            profile_object.can_add = can_add_properties

        profile_object.is_pro = True
        profile_object.strip_costumer_token = cs_token
        profile_object.strip_subscription_token = subscription
        profile_object.pro_start_date = datetime.now()
        profile_object.is_yearly = is_yearly
        # subject = '311Alert Payment Sucessful'

        profile_object.save()

        try:
            user_payment = Userpayments.objects.get(user=user)
            user_payment.total_payment += total_money
            user_payment.recent_payment = total_money
            user_payment.recent_payment_is_yearly = is_yearly
            user_payment.customer_token = profile_object.strip_costumer_token,
            user_payment.subscription_token = profile_object.strip_subscription_token
            user_payment.save()
        except:
            pass

    return HttpResponse(status=200)


def change_subscription(request):
    if request.method == 'POST':
        user_obj = request.user
        profile = Profile.objects.filter(user=user_obj).first()
        number_of_properties = int(
            request.POST.get('number')) + int(profile.can_add)
        new_billing_interval = request.POST.get('subscription_interval')
        price_id = None
        is_yearly = None

        price = Price.objects.first()

        if new_billing_interval == "monthly":
            price_id = price.price_change_to_month
            is_yearly = False

        else:
            price_id = price.price_change_to_year
            is_yearly = True

        customer = stripe.Customer.retrieve(profile.strip_costumer_token)
        subscription = stripe.Subscription.retrieve(
            profile.strip_subscription_token)
        subscription_id = subscription['items']['data'][0]['id']

        updated_subscription = stripe.Subscription.modify(
            subscription.id,
            proration_behavior='create_prorations',
            items=[{
                # 'id': subscription['items']['data'][0].id,
                'id': subscription_id,
                'price': price_id,
                'quantity': number_of_properties,
            }],
            metadata={"updated": "yes",
                      "user_id": user_obj.id,
                      'next_price_id': price_id,
                      "properties": number_of_properties,
                      "is_yearly": is_yearly
                      },


            proration_date=int(time.time()),
            billing_cycle_anchor='now',  # Start the new billing cycle immediately
        )

        print("This is Subscription Updated")
        print(updated_subscription)

        return redirect('success_2')


def update_subscription(request):
    return render(request, 'update_subscrption.html')


def already_pro(request):
    return render(request, 'pro_user.html')


def success_second(request):
    return render(request, 'success2.html')


def success(request):
    return render(request, 'success.html')


def cancel(request):
    return render(request, 'cancel.html')


def twenty_plus(request):
    return render(request, 'twenty_plus.html')
